push!(LOAD_PATH, "./models")
push!(LOAD_PATH, ".")

function asdf()
println("Super Wakas")
end

asdf();
