% Personal README: Francisco Romero Hinrichsen	

% 22/12/2017

The simulations are obtained by running the ufus.jl script, it stores the results in the data folder. 

To plot a particular experiment result, use the plot_ufus.jl script, for instance

> julia plots_ufus.jl "data/2017-11-02T10-01-19-625" 

will load the experiment with that name on the data folder. Inside the same folder you can find the 
considered parameters for that respective simulation.


